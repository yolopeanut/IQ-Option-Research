<h1 align="center">Albert Bot</h1>

<p align="right">
  <a href="https://www.youtube.com/watch?v=_JOfPOYtgpk&t=6s"><img alt="Youtube" title="Youtube" src="https://img.shields.io/youtube/views/_JOfPOYtgpk?label=Views&logo=Youtube&style=plastic"/></a>
      <a href="https://www.youtube.com/watch?v=_JOfPOYtgpk&t=6s"><img alt="Youtube" title="Youtube" src="https://img.shields.io/youtube/likes/_JOfPOYtgpk?label=Likes&logo=Youtube&style=plastic"/></a>
    

<h3 align="left"> Como instalar? </h3>
<p>O Albert BOT utiliza uma <a href="https://github.com/Lu-Yi-Hsun/iqoptionapi">API Open Source</a> desenvolvida por <a href="https://github.com/Lu-Yi-Hsun/">Anson</a> e a instalação da mesma é necessária para o funcionamento correto do automatizador.</p>
<p>Além da iqoptionapi, as bibliotecas <a href="https://pypi.org/project/PySimpleGUI/">PySimpleGUI</a> e <a href="https://docs.python.org/3/library/multiprocessing.html">Multiprocessing</a> deverão ser instaladas para o funcionamento correto.</p>
<p>Caso deseje utilizar apenas a versão compilada do código, você pode utilizar o <a href="https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqa1A0N3psVlRVbFJGeVJzMXV1NzRYVkszOXJkd3xBQ3Jtc0tuWTFnSXFZemVTUUZLV19LWkd0ZmRscGNHSkF3Mi05ZGNBemZ2RmlxV21vazhtR21NQjY1NG9uRUo1V2xPVVk1ekN1ZEUwc0RsX1VVbk5yQUdFNUZINnJBdXFIYURZTURRX0tEenc2ZUNJbDB6emZLQQ&q=https%3A%2F%2Fwww.mediafire.com%2Ffile%2Fu6rilbxr4bztqh0%2FAlbert-BOT.zip%2Ffile">link de download</a></p>
<h1 align="center">
    <a>Bot de investimentos</a>
</h1>

<p align="center">Codigo fonte do automatizador</p>

<p align="center" src="https://youtu.be/_JOfPOYtgpk">Vídeo de apresentação do bot</p>

<p align="center">https://youtu.be/_JOfPOYtgpk</p>
         
<p align="center" src="https://youtu.be/ZMZeV3Fnux8">Vídeo do funcionamento</p>

<p align="center">https://youtu.be/ZMZeV3Fnux8</p>

<h4 align="center"> 
  🚀FINALIZADO🚀
</h4>
