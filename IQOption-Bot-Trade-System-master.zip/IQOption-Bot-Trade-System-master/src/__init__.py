# -*- coding: utf-8 -*-
"""The IQ Option API bot."""
