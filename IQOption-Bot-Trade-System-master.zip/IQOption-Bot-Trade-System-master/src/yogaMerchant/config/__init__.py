# -*- coding: utf-8 -*-
"""The bot config handler."""
