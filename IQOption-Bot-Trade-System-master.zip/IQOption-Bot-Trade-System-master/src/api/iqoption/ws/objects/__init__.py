# -*- coding: utf-8 -*-
"""Module for IQ Option API websocket objects."""
