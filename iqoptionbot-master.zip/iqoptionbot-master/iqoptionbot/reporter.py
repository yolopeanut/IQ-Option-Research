"""Module for IQ Option API reporter."""
