"""The IQ Option API bot."""
