"""Module for IQ Option API trade patterns."""
