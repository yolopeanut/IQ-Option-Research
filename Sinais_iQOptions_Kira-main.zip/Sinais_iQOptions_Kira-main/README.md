# Catalogador de Sinais - iQ Options By K1r4
Código para catalogador de sinais sa iQ Options
Feito para testes em moeda Digital com expiração de M1, M5 e M15

# Dúvidas de como usar:
Entre em contato pelo Git ou pelo Telegram @wilccampos

# Dê os devidos créditos se for usar o código, dá trabalho para desenvolver e ter comunicação com a API
