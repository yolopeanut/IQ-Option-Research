# Trader-BOT

A bot to make automatic operations within iqoption 
